#!/bin/bash

java -jar backend-rest-1.0-SNAPSHOT-jar-with-dependencies.jar -cp ./lib agh.aq21gui.Main
